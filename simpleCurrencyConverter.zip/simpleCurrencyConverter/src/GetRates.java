import java.io.*;
import javax.swing.JOptionPane;
public class GetRates {
    public static float getSpecificRate(String curr) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("res/upd/latest.dat"));
            String response = reader.readLine();
            
            // Find the start of the currency code
            int start = response.indexOf("\"" + curr + "\":");
            if (start == -1) {
                JOptionPane.showMessageDialog(null, "Currency code not found.");
                System.exit(-1);
                return -99;
            }
            start = start + curr.length() + 3;
            int end = response.indexOf(",", start);
            if (end == -1) {
                end = response.indexOf("}", start);
            }
            String rateString = response.substring(start, end);
            return Float.parseFloat(rateString.trim());
            
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "The currency data is not found. Please click the RELOAD icon to generate.");
        } catch (NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to parse the currency rate.");
        }
        return -99;
    }
    // Flags sourced from @lipis | [https://github.com/lipis/flag-icons/tree/main/flags]
    public static String getFlagDirectory(String curr) {
        return "res/flags/" + curr.substring(0,2).toLowerCase() + ".png";
    }
}
